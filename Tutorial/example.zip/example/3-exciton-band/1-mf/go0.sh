#!/bin/bash
#SBATCH -J fin_Q
#SBATCH -o myjob.o\%j
#SBATCH -e myjob.e\%j
#SBATCH -p development
#SBATCH -N 2
#SBATCH -n 112
#SBATCH -t 02:00:00
#SBATCH -A PHY20032

QEPATH='/home1/08237/bwhou/software/qe-6.7/bin'
BGWPATH1='/home1/08237/bwhou/software/BerkeleyGW-3.0.1/bin/'

cd ./2.1-wfn
ibrun $QEPATH/pw.x -nk 8 -input in > in.out
ibrun $QEPATH/pw2bgw.x -nk 8 -input pp_in > pp_out

cd ../2.2-wfnq
ibrun $QEPATH/pw.x -nk 8 -input in > in.out
ibrun $QEPATH/pw2bgw.x -nk 8 -input pp_in > pp_out
