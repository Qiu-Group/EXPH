#!/bin/bash
#SBATCH -J fin_Q
#SBATCH -o myjob.o\%j
#SBATCH -e myjob.e\%j
#SBATCH -p development
#SBATCH -N 10
#SBATCH -n 560
#SBATCH -t 02:00:00
#SBATCH -A PHY20032

QEPATH='/home1/08237/bwhou/software/qe-6.7/bin'
BGWPATH1='/home1/08237/bwhou/software/BerkeleyGW-3.0.1/bin/'


cd 4.1-wfn_co_fullgrid
ibrun $QEPATH/pw.x -nk 16 -input in > in.out
ibrun $QEPATH/pw2bgw.x -nk 16 -input pp_in > pp_out
cd ../
